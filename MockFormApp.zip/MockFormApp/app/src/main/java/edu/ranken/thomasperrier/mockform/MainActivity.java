package edu.ranken.thomasperrier.mockform;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Program Constants
    final String NIP = "NO INPUT PROVIDED FOR ";
    final String GENDERMALE = "Male";
    final String GENDERFEMALE = "Female";
    final String GENDERPREFERNOTTOANSWER = "Prefer Not To Answer";
    final String SHIFTMORNING = "Morning";
    final String SHIFTAFTERNOON = "Afternoon";
    final String SHIFTEVENING = "Evening";
    final String SETTINGSON = "On";
    final String SETTINGSOFF = "Off";

    // Program Widget Variables
    EditText editTextName;
    EditText editTextAddress;
    EditText editTextCity;
    Spinner spinnerState;
    EditText editTextZipCode;
    RadioGroup radioGroupGender;
    RadioButton radioButtonFemale;
    RadioButton radioButtonMale;
    RadioButton radioButtonPreferNotToAnswer;
    CheckBox checkBoxMorning;
    CheckBox checkBoxAfternoon;
    CheckBox checkBoxEvening;
    Switch switchSettings;
    ImageButton imageButtonToast;

    // Program Non-Widget Variables
    String name = "";
    String address = "";
    String city = "";
    String state = "";
    String zipCode = "";
    String gender = "";
    String shift = "";
    String settings = "";
    boolean keepGoing;
    boolean nameHasInput;
    boolean addressHasInput;
    boolean cityHasInput;
    boolean zipCodeHasInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextName = findViewById(R.id.editTextName);
        editTextAddress = findViewById(R.id.editTextAddress);
        editTextCity = findViewById(R.id.editTextCity);
        editTextZipCode = findViewById(R.id.editTextZipCode);
        radioGroupGender = findViewById(R.id.radioGroupGender);
        radioButtonFemale = findViewById(R.id.radioButtonFemale);
        radioButtonMale = findViewById(R.id.radioButtonMale);
        radioButtonPreferNotToAnswer = findViewById(R.id.radioButtonPreferNotToAnswer);
        checkBoxMorning = findViewById(R.id.checkBoxMorning);
        checkBoxAfternoon = findViewById(R.id.checkBoxAfternoon);
        checkBoxEvening = findViewById(R.id.checkBoxEvening);
        spinnerState = findViewById(R.id.spinnerState);
        switchSettings = findViewById(R.id.switchSettings);
        imageButtonToast = findViewById(R.id.imageButtonToast);

        keepGoing = true;
        nameHasInput = true;
        addressHasInput = true;
        cityHasInput = true;
        zipCodeHasInput = true;

        imageButtonToast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                keepGoing = checkForNoInput();

                if(keepGoing){
                    name = "NAME: " + editTextName.getText().toString() + "\n";
                    address = "ADDRESS: " + editTextAddress.getText().toString() + "\n";
                    city = "CITY: " + editTextCity.getText().toString() + "\n";
                    state = "STATE: " + spinnerState.getSelectedItem().toString() + "\n";
                    zipCode = "ZIP: " + editTextZipCode.getText().toString();
                    gender = "\nGENDER: " + getGenderSelection();
                    shift = "\nSHIFT: " + getShiftSelection();
                    settings = "\nSETTINGS: " + getSettingsStatus();
                    Toast toast = Toast.makeText(getApplicationContext(),name + address + city + state + zipCode + gender + shift + settings, Toast.LENGTH_LONG);
                    toast.show();
                }
            }
        });
    }

    private boolean checkForNoInput(){
        nameHasInput = checkForNameInput();
        if(nameHasInput){
            addressHasInput = checkForAddressInput();
            if(addressHasInput){
                cityHasInput = checkForCityInput();
                if(cityHasInput){
                    zipCodeHasInput = checkForZipCodeInput();
                    if(zipCodeHasInput){
                        return true;
                    }
                    else{
                        return false;
                    }
                }
                else{
                    return false;
                }
            }
            else{
                return false;
            }
        }
        else{
            return false;
        }
    }

    private boolean checkForNameInput(){
        if(editTextName.getText().toString().isEmpty()){
            Toast toast = Toast.makeText(getApplicationContext(), NIP + "NAME", Toast.LENGTH_LONG);
            toast.show();
            editTextName.setText("");
            editTextName.requestFocus();
            return false;
        }
        else{
            return true;
        }
    }

    private boolean checkForAddressInput(){
        if(editTextAddress.getText().toString().isEmpty()){
            Toast toast = Toast.makeText(getApplicationContext(), NIP + "ADDRESS", Toast.LENGTH_LONG);
            toast.show();
            editTextAddress.setText("");
            editTextAddress.requestFocus();
            return false;
        }
        else{
            return true;
        }
    }

    private boolean checkForCityInput(){
        if(editTextCity.getText().toString().isEmpty()){
            Toast toast = Toast.makeText(getApplicationContext(), NIP + "CITY", Toast.LENGTH_LONG);
            toast.show();
            editTextCity.setText("");
            editTextCity.requestFocus();
            return false;
        }
        else{
            return true;
        }
    }

    private boolean checkForZipCodeInput(){
        if(editTextZipCode.getText().toString().isEmpty()){
            Toast toast = Toast.makeText(getApplicationContext(), NIP + "ZIP CODE", Toast.LENGTH_LONG);
            toast.show();
            editTextZipCode.setText("");
            editTextZipCode.requestFocus();
            return false;
        }
        else{
            return true;
        }
    }

    private String getGenderSelection(){
        if(radioButtonMale.isChecked()){
            return GENDERMALE;
        }
        else if(radioButtonFemale.isChecked()){
            return GENDERFEMALE;
        }
        else{
            return GENDERPREFERNOTTOANSWER;
        }
    }

    private String getShiftSelection(){
        if(checkBoxMorning.isChecked()){
            if(checkBoxAfternoon.isChecked()){
                if(checkBoxEvening.isChecked()){
                    return SHIFTMORNING + " & " + SHIFTAFTERNOON + " & " + SHIFTEVENING;
                }
                else{
                    return SHIFTMORNING + " & " + SHIFTAFTERNOON;
                }
            }
            else if(checkBoxEvening.isChecked()){
                return SHIFTMORNING + " & " + SHIFTEVENING;
            }
            else{
                return SHIFTMORNING;
            }
        }
        else if(checkBoxAfternoon.isChecked()){
            if(checkBoxEvening.isChecked()){
                return SHIFTAFTERNOON + " & " + SHIFTEVENING;
            }
            else{
                return SHIFTAFTERNOON;
            }
        }
        else{
            return SHIFTEVENING;
        }
    }

    private String getSettingsStatus(){
        if(switchSettings.isChecked()){
            return SETTINGSON;
        }
        else{
            return SETTINGSOFF;
        }
    }

}
